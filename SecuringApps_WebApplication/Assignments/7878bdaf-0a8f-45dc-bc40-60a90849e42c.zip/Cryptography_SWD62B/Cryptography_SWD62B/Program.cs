﻿using System;
using System.Text;

namespace Cryptography_SWD62B
{
    class Program
    {
        static void Main(string[] args)
        {
            string pass = "Pa$$w0rd";
            string pass2 = "Pa$$wOrd";
            byte[] salt = CryptographicHelpers.GenerateSalt();

            //Console.WriteLine(
            //    CryptographicHelpers.Hash(pass, salt));
            //Console.WriteLine(
            //    CryptographicHelpers.Hash(pass2, salt));
            //Console.WriteLine(
            //   String.Join(", ",
            //       Encoding.UTF32.GetBytes("hello world")));
            //Console.WriteLine(
            //    String.Join(", ",
            //        CryptographicHelpers.SymmetricEncrypt(Encoding.UTF32.GetBytes("hello world"))));

            //string original = "Hello";
            //string encryptedString = CryptographicHelpers.SymmetricEncrypt(original);

            //// encrypted string can contain +, = and /
            //// make sure to encode for URL before sending
            //// decode after receiving
            //// e.g. use URI.encode and decode
            //Console.WriteLine(
            //    encryptedString
            //    );

            //Console.WriteLine(CryptographicHelpers.SymmetricDecrypt(encryptedString));

            var keyPair = CryptographicHelpers.GenerateAsymmetricKeys();
            Console.WriteLine(keyPair.Item1);
            Console.WriteLine(keyPair.Item2);

            byte[] passwordAsBytes = CryptographicHelpers.AsymetricEncrypt(
                    Encoding.UTF32.GetBytes(pass),
                    keyPair.Item1);

            Console.WriteLine(
                String.Join(", ", passwordAsBytes));

            byte[] decryptedPass = CryptographicHelpers.AsymmetricDecrypt(
                passwordAsBytes,
                keyPair.Item2);

            Console.WriteLine(
                Encoding.UTF32.GetString(decryptedPass));



        }
    }
}
